package com.example.mymodule;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.support.v4.app.*;


import org.json.JSONObject;

public class Library extends Fragment {

    public static Library newInstance(JSONObject jsonObject) {
        Bundle args = new Bundle();
        args.putString("json_config", jsonObject.toString());

        Library frag = new Library();
        frag.setArguments(args);
        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.library_layout, container, false);

        return rootView;
    }

    public Library(){
        Toast.makeText(this.getActivity(), "WE DID IT but in instance", Toast.LENGTH_SHORT).show();
        startNewActivity(this.getActivity(), "com.mdlive.AHS_mobile");

    }

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this.getActivity(), "WE DID IT", Toast.LENGTH_SHORT).show();
        startNewActivity(this.getActivity(), "com.mdlive.AHS_mobile");
    }





    public void startNewActivity(Context context, String packageName) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) {
            System.out.println("Intent NULL");
            // Bring user to the market or let them choose an app?
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.mdlive.AHS_mobile"));
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}